public class Hand {
    public Hand();
    public void clear();
    public void addCard(Card c);
    public void removeCard(Card c);
    public void removeCard(int position);
    public int getCardCount();
    public Card getCard(int position);
    public void sortBySuit();
    public void sortByValue();
}