import java.util.Scanner;

public class HighLow {
    public static void main(String[] args) {
        System.out.println("""
        You will play a simple card game called HighLow.
        A card is dealt from a deck of cards.
        You will have to predict whether the next card will be
        higher or lower.
        Your score in the game is the number of correct predicitons
        you make before you guess wrong.
        """);

        int gamesPlayed = 0;
        int sumOfScores = 0;
        double averageScore;
        boolean playAgain;
        Scanner userInput = new Scanner(System.in);

        do {
            int scoreThisGame;
            scoreThisGame = play();
            sumOfScores += scoreThisGame;
            gamesPlayed++;
            System.out.print("Play again? ");
            playAgain = userInput.nextBoolean();
        } while (playAgain);

        averageScore = ((double)sumOfScores) / gamesPlayed;

        System.out.println();
        System.out.println("You played " + gamesPlayed + " games.");
        System.out.printf("Your average score was %1.3f.\n", averageScore);
    }

    private static int play() {
        Deck deck = new Deck();
        Card currentCard;
        Card nextCard;
        int correctGuesses;
        char guess;
        deck.shuffle();

        correctGuesses = 0;
        currentCard = deck.dealCard();
        System.out.println("The first card is the " + currentCard);

        while (true) {
            System.out.print("Will the next card be higher (H) or lower (L)? ");

            do {
                Scanner myGuess = new Scanner(System.in);
                guess = myGuess.next().charAt(0);
                guess = Character.toUpperCase(guess);

                if (guess != 'H' && guess != 'L')
                    System.out.print("Please respond with H or L: ");
            } while (guess != 'H' && guess != 'L');

            nextCard = deck.dealCard();
            System.out.println("The next card is " + nextCard);
            
            if (nextCard.getValue() == currentCard.getValue()) {
                System.out.println("The value is the same as the previous card.");
                System.out.println("You lose on ties.");
                break;
            }

            else if (nextCard.getValue() > currentCard.getValue()) {
                if (guess == 'H') {
                    System.out.println("Your prediction was correct.");
                    correctGuesses++;
                }
                else {
                    System.out.println("Your prediction was incorrect.");
                    break;
                }
            }

            else {
                if (guess == 'L') {
                    System.out.println("Your prediction was correct.");
                    correctGuesses++;
                }
                else {
                    System.out.println("Your prediction was incorrect.");
                    break;
                }
            }

            currentCard = nextCard;
            System.out.println();
            System.out.println("The card is " + currentCard);
        }

        System.out.println();
        System.out.println("The game is over.");
        System.out.println("You made " + correctGuesses + " correct predictions.");
        System.out.println();
        return correctGuesses;
    }
}