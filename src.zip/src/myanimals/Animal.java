public class Animal {
    static int getAnimalCount() {
        return Cat.getCatCount() + Dog.getDogCount();
    }

    public static void main(String[] args) {
        System.out.println(Cat.getCatCount()); // No Cat objects created yet.

        Cat myCat = new Cat();
        myCat.meow();
        myCat.name = "Steve";
        myCat.age = 9;
        System.out.println(Cat.MAX_LIVES);

        Dog myDog = new Dog();
        myDog.bark();
        myDog.name = "Alex";
        myDog.age = 10;
        myDog.breed = "Golden Retriever";

        Cat myCat2 = new Cat();
        myCat2.meow();
        myCat2.name = "Len";
        myCat2.age = 8;
        myCat2.livesRemaining = 7;

        System.out.println(getAnimalCount()); // 3 animals
        System.out.println(Cat.getCatCount()); // 2 cats
        System.out.println(Dog.getDogCount()); // 1 dog
        System.out.println(myCat.getCatCount()); // Falls under Cat class, 2 cats
        System.out.println(myDog.breed + "s are cool.");
    }
}