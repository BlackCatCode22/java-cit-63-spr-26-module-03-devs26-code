public class Dog {
    private static int dogCount = 0;

    String name;
    int age;
    String breed;

    public void bark() {
        System.out.println("BARK");
    }

    public Dog() {
        dogCount++;
    }

    public static int getDogCount() {
        return dogCount;
    }
}