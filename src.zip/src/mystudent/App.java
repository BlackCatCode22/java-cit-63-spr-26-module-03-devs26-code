public class App {
    public static void main(String[] args) {

        Student myStudent = new Student();
        myStudent.firstName = "John";
        myStudent.lastName = "Doe";
        myStudent.major = "Business";
        myStudent.gpa = 3.0;
        myStudent.age = 21;
        myStudent.onProbation = true;

        Student myStudent2 = new Student();
        myStudent2.firstName = "Jane";
        myStudent2.lastName = "Doe";
        myStudent2.major = "Art";
        myStudent2.gpa = 3.5;
        myStudent2.age = 23;
        myStudent2.onProbation = false;

        System.out.println(myStudent.firstName + " does not like " + myStudent2.major + ".");
    }
}