// I am not sure if this is just a duplicate, 
// but personalized version of mystudent package.
// Just assuming though.

public class Driver {
    static void printItems(MyStuff[] myObjects) {
        for (MyStuff item : myObjects) {
            System.out.println("My " + item.name + " is " + item.color + " and is made out of " + item.material + ".");
        }
    }

    public static void main(String[] args) {
        MyStuff myObject = new MyStuff();
        myObject.name = "Phone";
        myObject.color = "Black";
        myObject.material = "Aluminimum";

        MyStuff myObject2 = new MyStuff();
        myObject2.name = "Water Bottle";
        myObject2.color = "Transparent";
        myObject2.material = "Plastic";

        MyStuff myObject3 = new MyStuff();
        myObject3.name = "Burger";
        myObject3.color = "Brown, Green, Red, Yellow";
        myObject3.material = "Bread, Patty, Lettuce, Tomato, Cheese";

        MyStuff[] myObjects = {
            myObject, 
            myObject2,
            myObject3
            };
        printItems(myObjects);
    }
}