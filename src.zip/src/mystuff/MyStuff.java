public class MyStuff {
    private static int objCount = 0;

    String name;
    String color;
    String material;

    public MyStuff() {
        objCount++;
    }

    public static int getObjCount() {
        return objCount;
    }
}